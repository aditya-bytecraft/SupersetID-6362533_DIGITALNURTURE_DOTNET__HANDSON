import React from 'react';

const BookDetails = () => (
    <div>
        <h2>Book Details</h2>
        <p><strong>Title: Master React</strong></p>
        <p>Price: 670</p>
        <p><strong>Title: Deep Dive into Angular 11</strong></p>
        <p>Price: 800</p>
        <p><strong>Title: Mongo Essentials</strong></p>
        <p>Price: 450</p>
    </div>
);

export default BookDetails;
