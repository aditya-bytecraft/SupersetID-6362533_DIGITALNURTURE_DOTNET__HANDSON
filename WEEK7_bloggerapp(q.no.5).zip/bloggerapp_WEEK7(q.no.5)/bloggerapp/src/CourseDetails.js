﻿import React from 'react';

const CourseDetails = () => (
    <div>
        <h2>Course Details</h2>
        <p><strong>Name: Angular</strong></p>
        <p>Date: 1/5/2021</p>
        <p><strong>Name: React</strong></p>
        <p>Date: 6/3/2020</p>
    </div>
);

export default CourseDetails;
