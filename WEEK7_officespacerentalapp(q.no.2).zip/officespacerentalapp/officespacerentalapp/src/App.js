import React from "react";
import OfficeSpace from "./Components/OfficeSpace";

function App() {
    return (
        <div className="App">
            <OfficeSpace />
        </div>
    );
}

export default App;
