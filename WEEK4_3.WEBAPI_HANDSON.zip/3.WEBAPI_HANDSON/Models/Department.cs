﻿namespace WebApiLab3.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
