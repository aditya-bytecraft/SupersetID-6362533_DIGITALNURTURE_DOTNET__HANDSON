﻿namespace WebApiLab3.Models
{
    public class Skill
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
